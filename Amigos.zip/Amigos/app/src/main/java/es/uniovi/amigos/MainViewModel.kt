package es.uniovi.amigos

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val locationFlow = application.createLocationFlow()

    val amigosList = MutableLiveData<List<Amigo>>()
    var userName: String? = null
    var userId: Int? = null

    private var locationJob: Job? = null

    init {
        startPolling()
        // IMPORTANTE: no arrancar ubicación aquí; aún no hay permisos.
        // startLocationUpdates()
    }

    private fun startPolling() {
        viewModelScope.launch {
            while (true) {
                try {
                    val response = RetrofitClient.api.getAmigos()
                    if (response.isSuccessful) {
                        amigosList.postValue(response.body())
                    }
                } catch (e: Exception) {
                    Log.e("Polling", "Error: ${e.message}")
                }
                delay(5000)
            }
        }
    }

    fun registerUserName(name: String) {
        userName = name
        Log.d("MainViewModel", "Nombre de usuario establecido: $userName")
        viewModelScope.launch {
            try {
                val response = RetrofitClient.api.getAmigoByName(name)
                if (response.isSuccessful) {
                    val amigo = response.body()
                    userId = amigo?.id
                    Log.d("MainViewModel", "ID recuperado: $userId")
                } else {
                    Log.e("MainViewModel", "Error API: ${response.code()}")
                }
            } catch (e: Exception) {
                Log.e("MainViewModel", "Error red: ${e.message}")
            }
        }
    }

    fun startLocationUpdates() {
        // Evita arrancar múltiples collectors si se llama varias veces
        if (locationJob?.isActive == true) return

        locationJob = viewModelScope.launch {
            locationFlow.collect { result ->
                if (result is LocationResult.NewLocation) {
                    val location = result.location
                    val currentId = userId
                    if (currentId != null) {
                        try {
                            val payload = AmigosApiService.LocationPayload(
                                lati = location.latitude,
                                longi = location.longitude
                            )
                            RetrofitClient.api.updateAmigoPosition(currentId, payload)
                        } catch (e: Exception) {
                            Log.e("API_PUT", "Fallo de red: ${e.message}")
                        }
                    }
                } else if (result is LocationResult.PermissionDenied) {
                    Log.w("Location", "Permiso de ubicación denegado")
                } else if (result is LocationResult.ProviderDisabled) {
                    Log.w("Location", "Proveedor GPS desactivado")
                }
            }
        }
    }
}