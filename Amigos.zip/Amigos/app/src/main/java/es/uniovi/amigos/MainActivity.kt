package es.uniovi.amigos

import android.Manifest
import android.app.AlertDialog
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import android.widget.EditText
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.preference.PreferenceManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker

class MainActivity : AppCompatActivity() {
    private var map: MapView? = null
    private val viewModel: MainViewModel by viewModels()

    private val requestPermissionLauncher =
        registerForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { permissions ->
            if (permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true) {
                viewModel.startLocationUpdates()
            }
        }

    private fun checkAndRequestLocationPermissions() {
        val permissionsToRequest = arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )

        if (permissionsToRequest.all
            { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }
        ) {
            Log.d("Permissions", "Permisos concedidos")
            // Si ya tenemos permisos al arrancar, iniciamos la escucha del GPS
            viewModel.startLocationUpdates()
        } else {
            requestPermissionLauncher.launch(permissionsToRequest)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 1. Cargar configuración de osmdroid
        val ctx: Context = applicationContext
        Configuration.getInstance().load(ctx, PreferenceManager.getDefaultSharedPreferences(ctx))

        // 2. Cargar el layout
        setContentView(R.layout.activity_main)

        // 3. Inicializar el mapa
        map = findViewById(R.id.map)
        map?.setTileSource(TileSourceFactory.MAPNIK)

        // --- ESTA LÍNEA ES CRÍTICA: ---
        map?.setLayerType(android.view.View.LAYER_TYPE_SOFTWARE, null)
        // ------------------------------

        // 4. Centrar mapa (en segundo plano o hilo principal, ambos valen aquí)
        lifecycleScope.launch {
            withContext(Dispatchers.Main) {
                centrarMapaEnEuropa()
            }
        }

        // Resto de observadores y permisos...
        viewModel.amigosList.observe(this@MainActivity) { listaDeAmigos ->
            if (listaDeAmigos != null) {
                paintAmigosList(listaDeAmigos)
            }
        }
        checkAndRequestLocationPermissions()

        if (viewModel.userName == null) {
            askUserName()
        }
    }

    private fun askUserName() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Identificación")
        builder.setMessage("Introduce tu nombre de usuario:")
        val input = EditText(this)
        builder.setView(input)
        builder.setPositiveButton("Aceptar") { _, _ ->
            val name = input.text.toString()
            if (name.isNotBlank()) {
                viewModel.registerUserName(name)
            }
        }
        builder.setCancelable(false)
        builder.show()
    }

    fun centrarMapaEnEuropa() {
        val mapController = map?.controller
        mapController?.setZoom(5.5)
        val startPoint = GeoPoint(48.8583, 2.2944)
        mapController?.setCenter(startPoint)
    }

    override fun onResume() {
        super.onResume()
        map?.onResume()
    }

    override fun onPause() {
        super.onPause()
        map?.onPause()
    }

    private fun addMarker(lat: Double, lon: Double, title: String?) {
        map?.let { mapaNoNulo ->
            val marker = Marker(mapaNoNulo)
            marker.position = GeoPoint(lat, lon)
            marker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
            marker.title = title ?: "Desconocido"
            mapaNoNulo.overlays.add(marker)
        }
    }

    private fun paintAmigosList(amigos: List<Amigo>) {
        map?.overlays?.clear()

        for (amigo in amigos) {
            addMarker(amigo.lati, amigo.longi, amigo.name)
        }
        map?.invalidate()
    }
}